# ExpandableTableView
A simplest demonstration of expandable UITableView without using third party libs.


#Screenshots

Single Section expanded

![alt text](https://github.com/iOSCuriosity/ExpandableTableView/blob/master/ExpandableTableView/Preview_singleExpanded.png)

Multiple Section expanded

![alt text](https://github.com/iOSCuriosity/ExpandableTableView/blob/master/ExpandableTableView/Preview_multipleExpanded.png)
