//
//  ViewController.m
//  slideImageView
//
//  Created by Rahul Chopra on 11/08/17.
//  Copyright © 2017 Bar Uncle. All rights reserved.
//

#import "ViewController.h"
#import "CollectionViewCell.h"

@interface ViewController ()
{
    NSMutableArray *slideImage;
    
    NSInteger rowIndex;
    NSTimer *scrollTimer;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    
    slideImage = [NSMutableArray arrayWithObjects:@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg", nil];
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return INT_MAX;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CollectionViewCell *cell = (CollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    
     NSInteger index = indexPath.row % slideImage.count;
    
    cell.imgView.image = [UIImage imageNamed:slideImage[index]];
    
    rowIndex = indexPath.row;
    NSUInteger numberOfRecords = slideImage.count;
    if (rowIndex <= numberOfRecords) {
        rowIndex = (rowIndex + 1);
    }
    else {
        rowIndex = 0;
    }
    
    
    scrollTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(startTimer:) userInfo:nil repeats:true];
    
    return cell;
}

- (void) startTimer:(NSTimer *)timer
{
    
   /*
    [UIView animateKeyframesWithDuration:1.0 delay:2.0 options:UIViewAnimationCurveEaseIn animations:^{
        
    } completion:nil]; */
    
    NSIndexPath *iPath1 = [NSIndexPath indexPathForItem:rowIndex inSection:0];
    
    [UIView animateWithDuration:1.0 delay:5 options:UIViewAnimationOptionCurveEaseIn animations:^{
        
       // [_collectionView scrollToItemAtIndexPath:rowIndex atScrollPosition:UICollectionViewScrollPositionLeft animated:NO];
        
    
        [_collectionView scrollToItemAtIndexPath:iPath1 atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
        
    } completion:nil
        //code for completion
       
    ];
}

@end
