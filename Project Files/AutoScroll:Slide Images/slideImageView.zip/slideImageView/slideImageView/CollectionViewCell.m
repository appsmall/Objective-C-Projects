//
//  CollectionViewCell.m
//  slideImageView
//
//  Created by Rahul Chopra on 11/08/17.
//  Copyright © 2017 Bar Uncle. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

@end
