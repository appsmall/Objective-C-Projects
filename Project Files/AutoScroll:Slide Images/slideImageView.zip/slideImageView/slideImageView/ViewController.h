//
//  ViewController.h
//  slideImageView
//
//  Created by Rahul Chopra on 11/08/17.
//  Copyright © 2017 Bar Uncle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UICollectionViewDelegate, UICollectionViewDataSource>



@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end

