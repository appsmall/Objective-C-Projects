//
//  AppDelegate.h
//  LJAutoScrollDemo
//
//  Created by Jinxing Liao on 10/13/15.
//  Copyright © 2015 Jinxing Liao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

