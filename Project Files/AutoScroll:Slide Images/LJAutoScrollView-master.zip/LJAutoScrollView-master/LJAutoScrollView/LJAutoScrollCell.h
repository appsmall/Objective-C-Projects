//
//  LJAutoScrollCell.h
//  Chitu
//
//  Created by Jinxing Liao on 10/13/15.
//  Copyright © 2015 Jinxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LJAutoScrollCell : UICollectionViewCell

@property (nonatomic, strong) UIView *customView;

@end
